# Patchfix Home Services – Static Website

A plain HTML, CSS and JavaScript version of the Patchfix website, ready to run on localhost. No build step, no Node.js, no database.

## Run locally

**Option 1 – Simple server (recommended)**

Open a terminal inside this folder and run one of:

```
python3 -m http.server 8000
```
```
npx serve .
```

Then open http://localhost:8000 in your browser.

**Option 2 – Open directly**

Double-click `index.html`. Everything works this way too.

## Folder structure

```
patchfix-site/
├── index.html                  Home page
├── service-electrical.html     Service pages
├── service-plumbing.html
├── service-appliances.html
├── service-cleaning.html
├── service-packers-movers.html
├── book.html                   Two-step booking form
├── booking-confirmation.html   Shown after booking
├── contact.html                Enquiry form
├── about.html
├── privacy-policy.html
├── terms-and-conditions.html
├── 404.html
├── css/style.css               All styles
├── js/
│   ├── main.js                 Mobile menu, FAQ accordion, footer year
│   ├── booking.js              Booking form logic
│   ├── confirmation.js         Confirmation page details
│   └── contact.js              Contact form logic
└── images/                     Logo, favicon, poster
```

## How the forms work

There is no backend. When someone submits a form, the data is saved in the browser's `localStorage`:

| Form | localStorage key |
|------|------------------|
| Booking (latest) | `patchfix_last_booking` |
| Booking (all) | `patchfix_bookings` |
| Contact enquiry | `patchfix_enquiries` |

To view saved data, open the browser DevTools, go to Application, then Local Storage. Data stays on that browser only and is **not** sent to you.

To receive real bookings, connect the forms to a service such as WhatsApp, email (Formspree, EmailJS) or your own API by editing `js/booking.js` and `js/contact.js`.

## Common edits

- **Phone number / WhatsApp:** search for `+91 082481 94154` and `9108248194154` across the `.html` files.
- **Colours:** change the variables at the top of `css/style.css` (`--coral` is the yellow accent, `--forest` the dark colour).
- **Services, FAQs and text:** edit the HTML files directly.
- **Logo and images:** replace the files in `images/`, keeping the same file names.

## Notes

- Fonts load from Google Fonts, so an internet connection is needed for the exact typography.
- The privacy policy and terms pages contain placeholder text. Replace it with reviewed legal text before publishing.
- The admin dashboard and sign-in pages from the original React project are not included, because they need a login service and database.
- Original source: the React/Vite app in `artifacts/patchfix` of the uploaded project.
